from ex12.GUI import GUI


if __name__ == '__main__':
    gui=GUI()
    gui.starting_the_window()
