##################################################
# FILE:ex0.py
# WRITER:Mohammad Ghanayem, mohammadgh, 208653220
# EXERCISE:intro2cs1 ex0 2018-2019
# DESCRIPTION:A simple program that prints "Hello World!" to
# the standard output (screen).
##################################################
print("Hello World!")