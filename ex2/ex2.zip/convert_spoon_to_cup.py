def convert_spoon_to_cup(x):
    return x/16

