def is_it_summer_yet(TopT,a,b,c):
    return (a>TopT and b>TopT)or(a>TopT and c>TopT)or(b>TopT and c>TopT)